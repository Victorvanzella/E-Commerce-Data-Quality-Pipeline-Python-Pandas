import pandas as pd

from src.transform import clean_sales
from src.validate import validate_clean_data


def build_test_df():
    return pd.DataFrame(
        {
            "ID_Pedido": [1, 2, 2, 3],
            "Data_Compra": ["2026-07-01", "2026-07-02", "2026-07-02", "2026-07-03"],
            "Cliente_ID": ["10", "11", "11", "12"],
            "Produto": ["Notebook", "Mouse", "Mouse", "Teclado"],
            "Categoria": ["Eletrônicos", "Acessórios", "Acessórios", "Acessórios"],
            "Quantidade": [1, None, None, 2],
            "Preco_Unitario": ["5000", "100", "100", "200"],
            "Status_Entrega": ["Entregue", None, None, "Pendente"],
        }
    )


def test_clean_sales_removes_duplicates_and_creates_total():
    clean, metrics = clean_sales(build_test_df())

    assert clean["ID_Pedido"].duplicated().sum() == 0
    assert "Total_Venda" in clean.columns
    assert metrics["duplicates_removed"] == 1


def test_clean_data_passes_quality_rules():
    clean, _ = clean_sales(build_test_df())
    assert validate_clean_data(clean) == []
