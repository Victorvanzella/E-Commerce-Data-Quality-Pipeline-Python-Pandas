from __future__ import annotations

import json
import logging
from pathlib import Path

from src.analytics import build_analytics
from src.extract import extract_sales
from src.generate_data import generate_raw_sales
from src.transform import clean_sales
from src.validate import profile_data, validate_clean_data


ROOT = Path(__file__).resolve().parents[1]
RAW_PATH = ROOT / "data" / "raw" / "sales_raw.csv"
PROCESSED_PATH = ROOT / "data" / "processed" / "sales_clean.csv"
REPORTS_DIR = ROOT / "reports"
LOG_PATH = ROOT / "logs" / "pipeline.log"
METRICS_PATH = ROOT / "reports" / "pipeline_metrics.json"


def configure_logging() -> None:
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(LOG_PATH, encoding="utf-8"),
            logging.StreamHandler(),
        ],
        force=True,
    )


def run_pipeline(generate_raw: bool = True) -> dict:
    configure_logging()
    logging.info("Pipeline started.")

    if generate_raw or not RAW_PATH.exists():
        generate_raw_sales(RAW_PATH)
        logging.info("Raw dataset generated: %s", RAW_PATH)

    raw_df = extract_sales(RAW_PATH)
    raw_profile = profile_data(raw_df)
    logging.info("Raw data loaded: %s rows.", len(raw_df))

    clean_df, transform_metrics = clean_sales(raw_df)
    errors = validate_clean_data(clean_df)

    if errors:
        for error in errors:
            logging.error("Validation error: %s", error)
        raise ValueError(f"Clean dataset failed validation: {errors}")

    PROCESSED_PATH.parent.mkdir(parents=True, exist_ok=True)
    clean_df.to_csv(PROCESSED_PATH, index=False)
    logging.info("Clean dataset saved: %s rows.", len(clean_df))

    analytics = build_analytics(clean_df, REPORTS_DIR)
    logging.info("Analytical outputs generated.")

    metrics = {
        "raw_profile": raw_profile,
        "transform": transform_metrics,
        "analytics": analytics,
        "validation_status": "PASSED",
    }

    METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
    METRICS_PATH.write_text(
        json.dumps(metrics, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    logging.info("Pipeline completed successfully.")
    return metrics


if __name__ == "__main__":
    result = run_pipeline(generate_raw=True)
    print(json.dumps(result, indent=2, ensure_ascii=False))
