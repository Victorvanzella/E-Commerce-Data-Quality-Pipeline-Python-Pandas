from __future__ import annotations

from pathlib import Path

import pandas as pd


def build_analytics(df: pd.DataFrame, output_dir: str | Path) -> dict:
    """Create business-ready analytical outputs from the clean dataset."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    revenue_by_category = (
        df.groupby("Categoria", as_index=False)["Total_Venda"]
        .sum()
        .sort_values("Total_Venda", ascending=False)
    )

    units_by_product = (
        df.groupby("Produto", as_index=False)["Quantidade"]
        .sum()
        .sort_values("Quantidade", ascending=False)
    )

    revenue_by_product = (
        df.groupby("Produto", as_index=False)["Total_Venda"]
        .sum()
        .sort_values("Total_Venda", ascending=False)
    )

    daily_sales = (
        df.set_index("Data_Compra")
        .resample("D")["Total_Venda"]
        .sum()
        .reset_index()
    )

    delivery_status = (
        df["Status_Entrega"]
        .value_counts()
        .rename_axis("Status_Entrega")
        .reset_index(name="Quantidade_Pedidos")
    )
    delivery_status["Percentual"] = (
        delivery_status["Quantidade_Pedidos"] / delivery_status["Quantidade_Pedidos"].sum() * 100
    ).round(2)

    revenue_by_category.to_csv(output_dir / "revenue_by_category.csv", index=False)
    units_by_product.to_csv(output_dir / "units_by_product.csv", index=False)
    revenue_by_product.to_csv(output_dir / "revenue_by_product.csv", index=False)
    daily_sales.to_csv(output_dir / "daily_sales.csv", index=False)
    delivery_status.to_csv(output_dir / "delivery_status.csv", index=False)

    return {
        "total_revenue": float(df["Total_Venda"].sum()),
        "top_product_by_units": units_by_product.iloc[0]["Produto"],
        "top_product_by_revenue": revenue_by_product.iloc[0]["Produto"],
    }
