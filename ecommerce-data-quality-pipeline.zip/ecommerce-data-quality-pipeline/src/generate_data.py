from pathlib import Path

import numpy as np
import pandas as pd


PRODUCTS = ["Smartphone", "Notebook", "Fone de Ouvido", "Smartwatch", "Teclado Mecânico"]
CATEGORIES = ["Eletrônicos", "Eletrônicos", "Acessórios", "Acessórios", "Acessórios"]
PRICES = [5999.90, 8500.00, 799.50, 2100.00, 850.00]


def generate_raw_sales(output_path: str | Path, seed: int = 42) -> pd.DataFrame:
    """Generate the synthetic e-commerce dataset used as the raw layer.

    The dataset intentionally contains missing values, duplicates,
    invalid data types and an outlier so the cleaning pipeline can
    detect and correct data-quality problems.
    """
    np.random.seed(seed)

    data = {
        "ID_Pedido": range(1001, 1101),
        "Data_Compra": pd.to_datetime(
            pd.date_range(start="2026-07-01", periods=100, freq="D")
        ) - pd.to_timedelta(np.random.randint(0, 30, size=100), unit="d"),
        "Cliente_ID": np.random.randint(100, 150, size=100),
        "Produto": np.random.choice(PRODUCTS, size=100),
        "Categoria": CATEGORIES * 20,
        "Quantidade": np.random.randint(1, 5, size=100),
        "Preco_Unitario": PRICES * 20,
        "Status_Entrega": np.random.choice(
            ["Entregue", "Pendente", "Cancelado"],
            size=100,
            p=[0.80, 0.15, 0.05],
        ),
    }

    df = pd.DataFrame(data)

    # Intentionally inject data-quality issues.
    df.loc[5:10, "Quantidade"] = np.nan
    df.loc[20:22, "Status_Entrega"] = np.nan
    df.loc[30, "Cliente_ID"] = np.nan

    df = pd.concat([df, df.head(3)], ignore_index=True)

    df["Preco_Unitario"] = df["Preco_Unitario"].astype(str)
    df.loc[15, "Preco_Unitario"] = "valor_invalido"
    df["Cliente_ID"] = df["Cliente_ID"].astype(str)

    df.loc[50, "Quantidade"] = 50

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)

    return df


if __name__ == "__main__":
    generate_raw_sales("data/raw/sales_raw.csv")
    print("Raw dataset generated at data/raw/sales_raw.csv")
