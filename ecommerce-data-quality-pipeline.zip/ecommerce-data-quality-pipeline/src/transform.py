from __future__ import annotations

import pandas as pd


def clean_sales(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Clean and transform raw sales data.

    Rules are based on the source notebook:
    - coerce invalid numeric values;
    - fill Quantidade with the median;
    - fill Status_Entrega with the mode;
    - drop rows without Preco_Unitario or Cliente_ID;
    - remove duplicates;
    - remove extreme Quantidade values beyond mean + 3 std;
    - create Total_Venda.
    """
    clean = df.copy()

    initial_rows = len(clean)

    clean["Data_Compra"] = pd.to_datetime(clean["Data_Compra"], errors="coerce")
    clean["Preco_Unitario"] = pd.to_numeric(clean["Preco_Unitario"], errors="coerce")
    clean["Cliente_ID"] = pd.to_numeric(clean["Cliente_ID"], errors="coerce").astype("Int64")
    clean["Quantidade"] = pd.to_numeric(clean["Quantidade"], errors="coerce")

    median_quantity = clean["Quantidade"].median()
    clean["Quantidade"] = clean["Quantidade"].fillna(median_quantity)

    mode_status = clean["Status_Entrega"].mode(dropna=True)
    if not mode_status.empty:
        clean["Status_Entrega"] = clean["Status_Entrega"].fillna(mode_status.iloc[0])

    before_required_drop = len(clean)
    clean = clean.dropna(subset=["Preco_Unitario", "Cliente_ID", "Data_Compra"]).copy()
    dropped_required = before_required_drop - len(clean)

    before_duplicates = len(clean)
    clean = clean.drop_duplicates().copy()
    duplicates_removed = before_duplicates - len(clean)

    outlier_limit = clean["Quantidade"].mean() + 3 * clean["Quantidade"].std()
    before_outlier = len(clean)
    clean = clean[clean["Quantidade"] < outlier_limit].copy()
    outliers_removed = before_outlier - len(clean)

    clean["Quantidade"] = clean["Quantidade"].astype(int)
    clean["Total_Venda"] = clean["Quantidade"] * clean["Preco_Unitario"]

    clean = clean.sort_values(["Data_Compra", "ID_Pedido"]).reset_index(drop=True)

    metrics = {
        "initial_rows": int(initial_rows),
        "final_rows": int(len(clean)),
        "rows_dropped_missing_critical_fields": int(dropped_required),
        "duplicates_removed": int(duplicates_removed),
        "outliers_removed": int(outliers_removed),
        "median_quantity_used": float(median_quantity),
        "outlier_upper_limit": float(outlier_limit),
    }

    return clean, metrics
