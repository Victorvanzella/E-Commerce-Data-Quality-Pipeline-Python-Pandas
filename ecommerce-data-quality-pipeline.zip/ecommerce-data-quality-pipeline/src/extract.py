from pathlib import Path

import pandas as pd


REQUIRED_COLUMNS = [
    "ID_Pedido",
    "Data_Compra",
    "Cliente_ID",
    "Produto",
    "Categoria",
    "Quantidade",
    "Preco_Unitario",
    "Status_Entrega",
]


def extract_sales(path: str | Path) -> pd.DataFrame:
    """Read the raw sales CSV and validate the expected schema."""
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")

    df = pd.read_csv(path)

    missing_columns = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing_columns:
        raise ValueError(f"Missing required columns: {missing_columns}")

    return df
