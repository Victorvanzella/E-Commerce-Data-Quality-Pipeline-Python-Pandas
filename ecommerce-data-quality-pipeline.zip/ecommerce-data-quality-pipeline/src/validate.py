from __future__ import annotations

import pandas as pd


VALID_STATUS = {"Entregue", "Pendente", "Cancelado"}


def profile_data(df: pd.DataFrame) -> dict:
    """Return simple data-quality metrics for observability."""
    return {
        "rows": int(len(df)),
        "columns": int(len(df.columns)),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_values": {k: int(v) for k, v in df.isna().sum().to_dict().items()},
    }


def validate_clean_data(df: pd.DataFrame) -> list[str]:
    """Validate business/data-quality rules after transformation."""
    errors: list[str] = []

    if df.empty:
        errors.append("Dataset is empty.")

    if df["ID_Pedido"].duplicated().any():
        errors.append("Duplicate order IDs found.")

    if df.isna().any().any():
        errors.append("Missing values found.")

    if (df["Quantidade"] <= 0).any():
        errors.append("Quantidade must be greater than zero.")

    if (df["Preco_Unitario"] <= 0).any():
        errors.append("Preco_Unitario must be greater than zero.")

    invalid_status = set(df["Status_Entrega"].dropna().unique()) - VALID_STATUS
    if invalid_status:
        errors.append(f"Invalid delivery status: {sorted(invalid_status)}")

    if not pd.api.types.is_datetime64_any_dtype(df["Data_Compra"]):
        errors.append("Data_Compra is not datetime.")

    if not pd.api.types.is_numeric_dtype(df["Preco_Unitario"]):
        errors.append("Preco_Unitario is not numeric.")

    if not pd.api.types.is_numeric_dtype(df["Total_Venda"]):
        errors.append("Total_Venda is not numeric.")

    return errors
